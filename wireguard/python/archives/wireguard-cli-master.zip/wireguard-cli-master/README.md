# Dependencies
qrencode (sudo apt install qrencode)
