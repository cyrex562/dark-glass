# wg-utils
Little utilities for WireGuard

Liberally borrowed from [jimsalterjrs/wg-admin](https://github.com/jimsalterjrs/wg-admin)
