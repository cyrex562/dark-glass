pyroute2.ethtool
================

PyRoute2 is a pure Python **netlink** library.

This module provides Ethtool.

links
=====

* Home: <https://github.com/svinota/pyroute2/>
* PyPI: <https://pypi.org/project/pyroute2/>
* Usage: <https://github.com/svinota/pyroute2/discussions/796>
