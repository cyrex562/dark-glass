.. ndbaddresses:

IP addresses management
=======================

.. automodule:: pyroute2.ndb.objects.address
