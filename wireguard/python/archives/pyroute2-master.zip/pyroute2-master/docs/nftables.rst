.. _nftables:

NFTables module
============

.. automodule:: pyroute2.nftables
    :members:

.. automodule:: pyroute2.nftables.expr
    :members:

.. automodule:: pyroute2.nftables.main
    :members:

.. automodule:: pyroute2.nftables.rule
    :members:
