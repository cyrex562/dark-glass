Documentation
-------------

That's the project documentation source. In order to build
html docs, one should install sphinx and run `make docs`
in the project's root directory.

Actual built docs are available at http://docs.pyroute2.org/
