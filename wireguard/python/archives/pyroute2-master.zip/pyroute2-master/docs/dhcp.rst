.. dhcp:

DHCP support
============

DHCP support in `pyroute2` is in very initial state, so it is
in the «Development section» yet. DHCP protocol has nothing
to do with netlink, but `pyroute2` slowly moving from
netlink-only library to some more general networking
framework.

.. automodule:: pyroute2.dhcp
    :members:

.. automodule:: pyroute2.dhcp.dhcp4socket
    :members:
