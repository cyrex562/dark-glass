.. _ndbroutes:

Routes management
=================

.. automodule:: pyroute2.ndb.objects.route
