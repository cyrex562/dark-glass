.. nlsocket:

.. automodule:: pyroute2.netlink.nlsocket
    :members:
