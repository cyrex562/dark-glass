.. ndbobjects:

Views and objects
=================

.. automodule:: pyroute2.ndb.objects

.. autoclass:: pyroute2.ndb.objects.RTNL_Object
    :members: create, set, snapshot, apply, commit, rollback
