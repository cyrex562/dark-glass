.. wiset:

WiSet module
============

.. automodule:: pyroute2.wiset
    :members:
