.. ipdbtoc:

IPDB module
===========

.. warning::
    The IPDB module is deprecated and obsoleted by NDB. Please consider
    using NDB instead.

.. toctree::
    :maxdepth: 2

    ipdb
