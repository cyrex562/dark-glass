.. ipset:

IPSet module
==============

.. automodule:: pyroute2.ipset
    :members:
