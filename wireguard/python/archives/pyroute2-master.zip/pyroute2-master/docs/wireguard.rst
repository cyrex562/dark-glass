.. _wireguard:

WireGuard module
================

.. automodule:: pyroute2.netlink.generic.wireguard
