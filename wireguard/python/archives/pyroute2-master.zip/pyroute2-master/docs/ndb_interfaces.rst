.. _ndbinterfaces:

Network interfaces
==================

.. automodule:: pyroute2.ndb.objects.interface
