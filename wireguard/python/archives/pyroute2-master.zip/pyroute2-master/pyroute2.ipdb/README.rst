pyroute2.ipdb
=============

PyRoute2 is a pure Python **netlink** library.

IPDB module is approaching its end of life.

Details: <https://github.com/svinota/pyroute2/discussions/788>

links
=====

* Home: <https://github.com/svinota/pyroute2/>
* PyPI: <https://pypi.org/project/pyroute2/>
* Usage: <https://github.com/svinota/pyroute2/discussions/796>
