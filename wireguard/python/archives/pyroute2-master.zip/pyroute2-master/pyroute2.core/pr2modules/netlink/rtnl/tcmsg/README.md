See the API description in `sched_template.py`
