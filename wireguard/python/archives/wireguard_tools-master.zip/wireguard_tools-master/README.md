# wireguard_tools
only base config gen
