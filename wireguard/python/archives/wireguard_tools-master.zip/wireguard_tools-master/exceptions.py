class CountException(Exception):
    pass

class ValidationError(Exception):
    pass