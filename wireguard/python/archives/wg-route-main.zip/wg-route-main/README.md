# wg-route
Routing for Wireguard multi-region VPN setup
