export { ModalConfirmComponent } from './modal-confirm.component';
