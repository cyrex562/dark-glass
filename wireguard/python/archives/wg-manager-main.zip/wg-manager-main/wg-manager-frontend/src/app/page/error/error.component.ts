import { Component, HostBinding } from '@angular/core';

@Component({
  selector: 'app-error',
  styleUrls: ['error.component.css'],
  templateUrl: './error.component.html',
})
export class ErrorComponent { }
