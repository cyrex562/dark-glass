import { Component } from '@angular/core';

@Component({
  selector: 'app-components',
  template: '',
  styles: [''],
})
export class ComponentsComponent {

}
