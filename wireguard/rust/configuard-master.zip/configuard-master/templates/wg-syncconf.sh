{{ wireguard_bin }} syncconf wg0 {{ wireguard_conf }}
