route del {{ ipv4_address }}/32 -interface wg0
