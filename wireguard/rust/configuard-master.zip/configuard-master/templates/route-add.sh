route add {{ ipv4_address }}/32 -interface wg0
