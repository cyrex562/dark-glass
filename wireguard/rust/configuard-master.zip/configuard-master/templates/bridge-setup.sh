ifconfig bridge0 inet {{ router_ip_address }}{{ net_mask }} up
