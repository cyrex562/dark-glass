# rwg - rusty wireguard

WireGuard administration library for the Rust programming language.

## Licence

This project is licensed under [GPLv2](LICENCE.md)
