#!/bin/sh
cp ./target/release/wg-switch /usr/bin/wg-switch