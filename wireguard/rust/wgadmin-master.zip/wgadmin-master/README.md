# wgadmin

Web UI for WireGuard administration.

---

![preview](doc/preview.png)

## Licence

This project is licenced under [GPLv2](LICENCE.md)
