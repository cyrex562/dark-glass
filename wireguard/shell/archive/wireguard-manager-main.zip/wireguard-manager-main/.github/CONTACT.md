| Service                                | Description                            |
|----------------------------------------|----------------------------------------|
| Name                                   | Prajwal Koirala                        |
| Email                                  | prajwalkoirala23[at]protonmail[dot]com |
| Website                                | prajwalkoirala.com                     |
| Github                                 | github.com/prajwal-koirala             |
| LinkedIn                               | linkedin.com/in/prajwal-koirala        |
| Twitter                                | twitter.com/Prajwal_K23                |
| Reddit                                 | reddit.com/user/prajwalkoirala23       |
| Twitch                                 | twitch.tv/prajwalkoirala23             |
