`complete` :heavy_check_mark:

Most of the project is completed, some bug fixing or security fixing may take place.

`active` :heart:

The venture is under active growth.

`abandoned` :x:

There could be an unfinished project, Identified as a project that for the purposes of this analysis has been entirely abandoned, or indefinitely postponed. At any point of a project lifecycle, abandonment can occur and cause severe losses.
