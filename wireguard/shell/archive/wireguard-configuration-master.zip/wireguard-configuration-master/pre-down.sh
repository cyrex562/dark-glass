#!/bin/bash

echo Delete rules... >&2
cd "$(dirname ${BASH_SOURCE[0]})"
source ./clean.sh
echo Delete rules done. >&2
