#!/bin/bash

echo Add rules... >&2
cd "$(dirname ${BASH_SOURCE[0]})"
source ./rule.sh
echo Add rules done. >&2
