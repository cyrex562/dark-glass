#!/bin/sh -lxe

checkbashisms -fx easy-wg-quick
