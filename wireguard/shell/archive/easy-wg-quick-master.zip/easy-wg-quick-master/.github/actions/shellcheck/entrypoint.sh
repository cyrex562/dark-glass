#!/bin/sh -lxe

shellcheck -s sh easy-wg-quick
