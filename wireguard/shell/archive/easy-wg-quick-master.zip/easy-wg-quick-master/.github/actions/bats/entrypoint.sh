#!/bin/sh -lxe

cd tests
./runtests.bash
