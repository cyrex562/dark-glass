#!/bin/sh -lxe

./easy-wg-quick
./easy-wg-quick
./easy-wg-quick client01
./easy-wg-quick client02
./easy-wg-quick
