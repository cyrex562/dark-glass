#!/usr/bin/env bash

teardown() {
    rm -f ./*.bak ./*.conf ./*.key ./*.txt
}
