#!/usr/bin/env bash

setup() {
    teardown
}
